
#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`
