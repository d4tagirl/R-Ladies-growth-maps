[![Travis-CI Build Status](https://travis-ci.org/AndySouth/rworldmap.png?branch=master)](https://travis-ci.org/AndySouth/rworldmap)
[![rstudio mirror downloads](http://cranlogs.r-pkg.org/badges/grand-total/rworldmap)](https://github.com/metacran/cranlogs.app)
[![rstudio mirror downloads](http://cranlogs.r-pkg.org/badges/rworldmap)](https://github.com/metacran/cranlogs.app)
[![Research software impact](http://depsy.org/api/package/cran/rworldmap/badge.svg)](http://depsy.org/package/r/rworldmap)

# rworldmap
R package for mapping global data

### Installation from CRAN
    install.packages('rworldmap',dependencies=TRUE) 

### Development version

    require(devtools)    
    install_github('AndySouth/rworldmap', build_vignettes=TRUE) 
