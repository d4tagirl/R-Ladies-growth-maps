`.onAttach`<-
function(libname,pkgname){

packageStartupMessage("### Welcome to rworldmap ###")
#packageStartupMessage("For help files type :           \t help(rworldmap,help_type='html')")
packageStartupMessage("For a short introduction type : \t vignette('rworldmap')")
}
